<?php
	/* Template Name: Ajax End-Point Page */  
	get_header(); 
?>

	<section id="about" class="courses_head">
	      <h2>PROJECTS LIST From Ajax End-Point</h2>
	</section>
	<section id="courses">
        <div class="course_box">
        	
        </div>
	</section>
<?php get_footer(); ?>

